﻿namespace TimesheetInterface.Models
{
    public class Timesheets
    {
        public int Id { get; set; }

        //IDs
        public int EmployeeId { get; set; }
        public int TaskId { get; set; }

        //Time Data
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public bool IsCompleted { get; set; }


        //Navigational Properties
        public Employees Employees { get; set; }
        public Tasks Tasks { get; set; }
    }
}
