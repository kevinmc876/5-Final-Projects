﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace TimesheetInterface.Models
{
    public class TimesheetVM
    {
        public int Id { get; set; }

        //ID
        public int EmployeeId { get; set; }
        public int TaskId { get; set; }

        //Dropdown
        public List<SelectListItem> EmployeesList { get; set; }
        public List<SelectListItem> TasksList { get; set; }


        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public bool IsCompleted { get; set; }


        // Navigation
        [Display(Name = "Employee")]
        public int SelectedEmployee{ get; set; }

        [Display(Name = "Task")]
        public int SelectedTask { get; set; }
    }
}
