﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using TimesheetInterface.Models;

namespace TimesheetInterface.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
		
        //Post that pushes the controller to redirect to the specified controller
		[HttpPost]
        public IActionResult Index(IFormCollection form)
        {
			//Gets the value from the form on the Index.
			string id = form["id"].ToString();
			//Create a string that transfers the user to the Employee Controller
			return RedirectToAction("Index", "EmployeeTimesheet", new {employeeId = id});
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Contact()
        {
            return View();
        }
    }
}