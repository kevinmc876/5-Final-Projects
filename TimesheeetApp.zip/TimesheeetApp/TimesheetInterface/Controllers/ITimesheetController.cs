﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Text;
using TimesheetInterface.Models;

namespace TimesheetInterface.Controllers
{
    public class ITimesheetController : Controller
    {
        const string URL = "https://localhost:7222/api/Timesheet/";

        private readonly IHttpClientFactory _httpClientFactory;

        public ITimesheetController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        //Index Page
        public IActionResult Index()
        {
            var timesheets = new List<Timesheets>();
            var httpclient = _httpClientFactory.CreateClient("Timesheet");

            HttpResponseMessage response = httpclient.GetAsync(URL).Result;
            if (response.IsSuccessStatusCode)
            {
                var data = response.Content.ReadAsStringAsync().Result;
                timesheets = JsonConvert.DeserializeObject<List<Timesheets>>(data);
            }

            return View(timesheets);
        }

        //Details Page
        [HttpGet]
        public IActionResult Details(int id)
        {
            Timesheets timesheets = new Timesheets();
            var httpclient = _httpClientFactory.CreateClient("Timesheet");

            HttpResponseMessage response = httpclient.GetAsync($"{URL}{id}").Result;
            if (response.IsSuccessStatusCode)
            {
                var data = response.Content.ReadAsStringAsync().Result;
                timesheets = JsonConvert.DeserializeObject<Timesheets>(data)!;
            }

            return View(timesheets);
        }

        //Edit Page
        [HttpGet]
        public IActionResult Edit(int id)
        {
            List<Tasks> taskList = new List<Tasks>();
            List<Employees> employeesList = new List<Employees>();

            Timesheets timesheets = new Timesheets();

            var httpclient = _httpClientFactory.CreateClient("Timesheet");

            //Task List Response
            HttpResponseMessage tresponse = httpclient.GetAsync($"{URL}Tasks").Result;
            if (tresponse.IsSuccessStatusCode)
            {
                var data = tresponse.Content.ReadAsStringAsync().Result;
                taskList = JsonConvert.DeserializeObject<List<Tasks>>(data)!;
            }

            //Employee List Response
            HttpResponseMessage eresponse = httpclient.GetAsync($"{URL}Employee").Result;
            if (eresponse.IsSuccessStatusCode)
            {
                var data = eresponse.Content.ReadAsStringAsync().Result;
                employeesList = JsonConvert.DeserializeObject<List<Employees>>(data)!;
            }

            //Timesheet List
            HttpResponseMessage response = httpclient.GetAsync($"{URL}{id}").Result;
            if (response.IsSuccessStatusCode)
            {
                var data = response.Content.ReadAsStringAsync().Result;
                timesheets = JsonConvert.DeserializeObject<Timesheets>(data)!;
            }

            var ViewModel = new TimesheetVM
            {
                Id = timesheets.Id,
                EmployeeId = timesheets.EmployeeId,
                TaskId = timesheets.TaskId,
                StartTime = timesheets.StartTime,
                EndTime = timesheets.EndTime,
                IsCompleted = timesheets.IsCompleted,
                SelectedEmployee = timesheets.EmployeeId,
                SelectedTask = timesheets.TaskId,

                TasksList = taskList.Select(t => new SelectListItem
                {
                    Text = t.Name,
                    Value = t.Id.ToString()
                }).ToList(),

                EmployeesList = employeesList.Select(e => new SelectListItem
                {
                    Text = e.Name,
                    Value = e.EmployeeId.ToString()
                }).ToList()
            };

            return View(ViewModel);
        }
        [HttpPost]
        public IActionResult Edit(int id, TimesheetVM timesheetVM)
        {
            var httpclient = _httpClientFactory.CreateClient("Timesheet");

            var Timesheet = new TimesheetVM
            {
                Id = timesheetVM.Id,
                EmployeeId = timesheetVM.SelectedEmployee,
                TaskId = timesheetVM.SelectedTask,
                StartTime = timesheetVM.StartTime,
                EndTime = timesheetVM.EndTime,
                IsCompleted = timesheetVM.IsCompleted,
            };

            var json = JsonConvert.SerializeObject(Timesheet);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            HttpResponseMessage response = httpclient.PutAsync($"{URL}{id}", content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Unable to Update Employee's Record");
                return View(Timesheet);
            }
        }


        //Create Page
        [HttpGet]
        public IActionResult Create()
        {
            List<Tasks> taskList = new List<Tasks>();
            List<Employees> employeesList = new List<Employees>();

            var httpclient = _httpClientFactory.CreateClient("Timesheet");

            //Task List Response
            HttpResponseMessage tresponse = httpclient.GetAsync($"{URL}Tasks").Result;
            if (tresponse.IsSuccessStatusCode)
            {
                var data = tresponse.Content.ReadAsStringAsync().Result;
                taskList = JsonConvert.DeserializeObject<List<Tasks>>(data)!;
            }
            //Employees List Response
            HttpResponseMessage eresponse = httpclient.GetAsync($"{URL}Employee").Result;
            if (eresponse.IsSuccessStatusCode)
            {
                var data = eresponse.Content.ReadAsStringAsync().Result;
                employeesList = JsonConvert.DeserializeObject<List<Employees>>(data)!;
            }

            var ViewModel = new TimesheetVM
            {
                TasksList = taskList.Select(t => new SelectListItem
                {
                    Text = t.Name,
                    Value = t.Id.ToString()

                }).ToList(),

                EmployeesList = employeesList.Select(e => new SelectListItem
                {
                    Text = e.Name,
                    Value = e.EmployeeId.ToString()

                }).ToList()
            };

            return View(ViewModel);
        }
        [HttpPost]
        public IActionResult Create(TimesheetVM timesheetVM)
        {
            var httpclient = _httpClientFactory.CreateClient("Timesheet");

            var timesheetlist = new Timesheets
            {
                Id = timesheetVM.Id,
                EmployeeId = timesheetVM.SelectedEmployee,
                TaskId = timesheetVM.SelectedTask,
                StartTime = timesheetVM.StartTime,
                EndTime = timesheetVM.EndTime,
                IsCompleted = timesheetVM.IsCompleted,

            };

            var json = JsonConvert.SerializeObject(timesheetlist);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            HttpResponseMessage response = httpclient.PostAsync(URL, content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Unable to Create Employee's Record");
                return View(timesheetVM);
            }
        }

        //Delete Page
        [HttpGet]
        public IActionResult Delete(int id)
        {
            Timesheets timesheets = new Timesheets();
            var httpclient = _httpClientFactory.CreateClient("Timesheet");


            HttpResponseMessage response = httpclient.GetAsync($"{URL}{id}").Result;
            if (response.IsSuccessStatusCode)
            {
                var data = response.Content.ReadAsStringAsync().Result;
                timesheets = JsonConvert.DeserializeObject<Timesheets>(data)!;
            }

            return View(timesheets);
        }
        [HttpPost]
        public IActionResult Delete(int id, Timesheets timesheets)
        {
            var httpclient = _httpClientFactory.CreateClient("Timesheet");

            HttpResponseMessage response = httpclient.DeleteAsync($"{URL}{id}").Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Unable to Delete TimeSheet");
                return View(timesheets);
            }
        }
    }
}
