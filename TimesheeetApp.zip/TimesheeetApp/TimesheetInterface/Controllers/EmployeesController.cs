﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;
using TimesheetInterface.Models;

namespace TimesheetInterface.Controllers
{
    public class EmployeesController : Controller
    {
        const string URL = "https://localhost:7222/api/Timesheet/Employee/";

        private readonly IHttpClientFactory _httpClientFactory;
        public EmployeesController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        //Index Page
        public IActionResult Index()
        {
            var employees = new List<Employees>();
            var httpclient = _httpClientFactory.CreateClient("Timesheet");

            HttpResponseMessage response = httpclient.GetAsync($"{URL}").Result;
            if (response.IsSuccessStatusCode)
            {
                var data = response.Content.ReadAsStringAsync().Result;
                employees = JsonConvert.DeserializeObject<List<Employees>>(data)!;
            }

            return View(employees);
        }

        //Details Page
        [HttpGet]
        public IActionResult Details(int id)
        {
            var employee = new Employees();
            var httpclient = _httpClientFactory.CreateClient("Timesheet");

            HttpResponseMessage response = httpclient.GetAsync($"{URL}{id}").Result;
            if (response.IsSuccessStatusCode)
            {
                var data = response.Content.ReadAsStringAsync().Result;
                employee = JsonConvert.DeserializeObject<Employees>(data)!;
            }

            return View(employee);
        }

        //Edit Page
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var employee = new Employees();
            var httpclient = _httpClientFactory.CreateClient("Timesheet");

            HttpResponseMessage response = httpclient.GetAsync($"{URL}{id}").Result;
            if (response.IsSuccessStatusCode)
            {
                var data = response.Content.ReadAsStringAsync().Result;
                employee = JsonConvert.DeserializeObject<Employees>(data)!;
            }

            return View(employee);
        }
        [HttpPost]
        public ActionResult Edit(int id, Employees employees)
        {
            var httpclient = _httpClientFactory.CreateClient("Timesheet");

            var json = JsonConvert.SerializeObject(employees);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            HttpResponseMessage response = httpclient.PutAsync($"{URL}{id}", content).Result; 
            if (response.IsSuccessStatusCode) 
            {
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Unable to Update Employee's Record");
                return View(employees);
            }
        }


        //Create Page
        [HttpGet]
        public ActionResult Create()
        {
            return View(new Employees());
        }
        [HttpPost]
        public IActionResult Create(Employees employees)
        {
            var httpclient = _httpClientFactory.CreateClient("Timesheet");

            var json = JsonConvert.SerializeObject(employees);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            HttpResponseMessage response = httpclient.PostAsync($"{URL}", content).Result;
            if (response.IsSuccessStatusCode) 
            {
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Unable to Create Employee's Record");
                return View(employees);
            }
        }

        //Delete Page
        [HttpGet]
        public ActionResult Delete(int id)
        {
            var employee = new Employees();
            var httpclient = _httpClientFactory.CreateClient("Timesheet");

            HttpResponseMessage reponse = httpclient.GetAsync($"{URL}{id}").Result;
            if (reponse.IsSuccessStatusCode)
            {
                var data = reponse.Content.ReadAsStringAsync().Result;
                employee = JsonConvert.DeserializeObject<Employees>(data)!;
            }

            return View(employee);
        }
        [HttpPost]
        public ActionResult Delete (int id, Employees employees)
        {
            var httpclient = _httpClientFactory.CreateClient("Timesheet");

            HttpResponseMessage response = httpclient.DeleteAsync($"{URL}{id}").Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction ("Index");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Unable to Delete TimeSheet");
                return View(employees);
            }
        }

    }
}
