﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TimesheetAPI.Data;
using TimesheetAPI.Models;

namespace TimesheetAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TimesheetController : ControllerBase
    {
        private readonly TimesheetDbContext _dbContext;
        public TimesheetController(TimesheetDbContext dbContext)
        {
            _dbContext = dbContext;
        }


        #region Timesheet Endpoint
        // Fetches All Timesheet Models
        [HttpGet]
        public IActionResult GetTimesheets()
        {
            try
            {
                var tItems = _dbContext.Timesheet
                .Include(b => b.Tasks)
                .Include(b => b.Employees)
                    .ToList();
                if (tItems == null)
                {
                    return NotFound("Timesheet Data Not Available");
                }

                return Ok(tItems);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // Fetches a Timesheet Model Based on the ID
        [HttpGet("{id}")]
        public IActionResult GetTimesheetById(int id)
        {
            var tItem = _dbContext.Timesheet
                .Include(b => b.Tasks)
                .Include(b => b.Employees)
                .FirstOrDefault(x => x.ID == id);

            if (tItem == null)
            {
                return NotFound();
            }

            return Ok(tItem);
        }

        // Creates a Timesheet Model
        [HttpPost]
        public IActionResult CreateTimesheet([FromBody] TimeSheet item)
        {
            _dbContext.Timesheet.Add(item);
            _dbContext.SaveChanges();

            return CreatedAtAction(nameof(GetTimesheetById), new { id = item.ID }, item);
        }

        // Updates a Timesheet Model
        [HttpPut("{id}")]
        public IActionResult UpdateTimesheet(int id, [FromBody] TimeSheet item)
        {
            if (id != item.ID)
            {
                return BadRequest();
            }

            _dbContext.Timesheet.Update(item);
            _dbContext.SaveChanges();

            return CreatedAtAction(nameof(GetTimesheetById), new { id = item.ID }, item);
        }

        // Delete a Timesheet Model
        [HttpDelete("{id}")]
        public IActionResult DeleteTimesheet(int id)
        {
            try
            {
                var tItem = _dbContext.Timesheet
                    .Include (b => b.Tasks)
                    .Include (b => b.Employees)
                    .FirstOrDefault(x => x.ID == id);

                if (tItem == null) return NotFound();

                _dbContext.Entry(tItem).State = EntityState.Deleted;
                _dbContext.SaveChanges();

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion


        #region Task Endpoint
        // Fetches All Task Models
        [HttpGet]
        [Route("Tasks")]
        public IActionResult GetTasks()
        {
            try
            {
                var taskItems = _dbContext.Tasks
                    .ToList();
                if (taskItems == null)
                {
                    return NotFound("Task Data Not Available");
                }

                return Ok(taskItems);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // Fetches a Task Model Based on the ID
        [HttpGet]
        [Route("Tasks/{id}")]

        public IActionResult GetTaskById(int id)
        {
            var taskItem = _dbContext.Tasks.FirstOrDefault(x => x.ID == id);

            if (taskItem == null)
            {
                return NotFound();
            }

            return Ok(taskItem);
        }

        // Creates a Task Model
        [HttpPost]
        [Route("Tasks")]

        public IActionResult CreateTask([FromBody] Tasks item)
        {
            _dbContext.Tasks.Add(item);
            _dbContext.SaveChanges();

            return CreatedAtAction(nameof(GetTaskById), new { id = item.ID }, item);
        }

        // Updates a Task Model
        [HttpPut]
        [Route("Tasks/{id}")]

        public IActionResult UpdateTask(int id, [FromBody] Tasks item)
        {
            if (id != item.ID)
            {
                return BadRequest();
            }

            _dbContext.Tasks.Update(item);
            _dbContext.SaveChanges();

            return CreatedAtAction(nameof(GetTaskById), new { id = item.ID }, item);
        }

        // Delete a Task Model
        [HttpDelete]
        [Route("Tasks/{id}")]

        public IActionResult DeleteTask(int id)
        {
            try
            {
                var taskItem = _dbContext.Tasks
                    .FirstOrDefault(x => x.ID == id);

                if (taskItem == null) return NotFound();

                _dbContext.Entry(taskItem).State = EntityState.Deleted;
                _dbContext.SaveChanges();

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion


        #region Employee Endpoint
        // Fetches All Employee Models
        [HttpGet]
        [Route("Employee")]

        public IActionResult GetEmployees()
        {
            try
            {
                var employeeItems = _dbContext.Employees
                    .ToList();
                if (employeeItems == null)
                {
                    return NotFound("Employee Data Not Available");
                }

                return Ok(employeeItems);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // Fetches an Employee Model Based on the ID
        [HttpGet]
        [Route("Employee/{id}")]

        public IActionResult GetEmployeeById(int id)
        {
            var employeeItem = _dbContext.Employees.FirstOrDefault(x => x.EmployeeID == id);

            if (employeeItem == null)
            {
                return NotFound();
            }

            return Ok(employeeItem);
        }

        // Creates an Employee Model
        [HttpPost]
        [Route("Employee")]

        public IActionResult CreateEmployee([FromBody] Employee item)
        {
            _dbContext.Employees.Add(item);
            _dbContext.SaveChanges();

            return CreatedAtAction(nameof(GetEmployeeById), new { id = item.EmployeeID }, item);
        }

        // Updates an Employee Model
        [HttpPut]
        [Route("Employee/{id}")]

        public IActionResult UpdateEmployee(int id, [FromBody] Employee item)
        {
            if (id != item.EmployeeID)
            {
                return BadRequest();
            }

            _dbContext.Employees.Update(item);
            _dbContext.SaveChanges();

            return CreatedAtAction(nameof(GetEmployeeById), new { id = item.EmployeeID }, item);
        }

        // Delete an Employee Model
        [HttpDelete]
        [Route("Employee/{id}")]

        public IActionResult DeleteEmployee(int id)
        {
            try
            {
                var employeeItem = _dbContext.Employees
                    .FirstOrDefault(x => x.EmployeeID == id);

                if (employeeItem == null) return NotFound();

                _dbContext.Entry(employeeItem).State = EntityState.Deleted;
                _dbContext.SaveChanges();

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion


    }
}
