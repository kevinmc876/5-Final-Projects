﻿using System.ComponentModel.DataAnnotations;

namespace TimesheetAPI.Models
{
    public class Employee
    {
        [Key]
        public int EmployeeID { get; set; }
        public string Name { get; set; }
        public string JobTitle { get; set; }
    }
}
