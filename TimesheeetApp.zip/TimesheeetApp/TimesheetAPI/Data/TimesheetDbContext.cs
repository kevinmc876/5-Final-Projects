﻿using System.Collections.Generic;
using System;
using Microsoft.EntityFrameworkCore;
using TimesheetAPI.Models;

namespace TimesheetAPI.Data
{
    public class TimesheetDbContext: DbContext
    {

            public TimesheetDbContext(DbContextOptions options) : base(options)
            {
            }

            public DbSet<Employee> Employees { get; set; }
            public DbSet<Tasks> Tasks { get; set; }
            public DbSet<TimeSheet> Timesheet{ get; set; }
        

    }
}
